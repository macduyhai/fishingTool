import requests

# trace GEO IP -------------------------------------------------------------------------------------------------

def tracegeoIp(ip):    
    params = {
        'apiKey':'95e3964c99f84deb8f2fcb49fea6b91b'
    }
    try:
        if '127.0.0.1' == ip:
            ip = 'https://ipgeolocation.io/json/'
        else:
            ip = 'https://api.ipgeolocation.io/ipgeo?ip=' + ip
        result = requests.get(ip,params=params).json()    
        print('tracegeoIp : ',result)    
    except Exception as e:
        print(e)
        result = "Error. Verify your network connection."
    return result
# --------------------------------------------------------------------------------------------------------------